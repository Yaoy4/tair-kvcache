import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
MODES = {
    "aggregated": {
        "label": "PD 合并（TP=2）",
        "path": ROOT / "cases_same_seed_flush_cache_32kv_GBps-tp2-dp1-PDagg-drc",
    },
    "disaggregated": {
        "label": "PD 分离（P1D1, TP=1）",
        "path": ROOT / "cases_same_seed_flush_cache_32kv_GBps-P1D1-tp1-dp1-PDdisagg",
    },
}
METRICS = ("ttft", "tpot", "e2e_latency")
REPRESENTATIVE_WORKLOADS = {(1024, 1024), (1024, 4096), (16384, 1024)}


def read_result(path: Path) -> dict:
    with path.open(encoding="utf-8") as source:
        result = json.loads(source.readline())
    return {
        "rr": result["request_rate"],
        "il": result["random_input_len"],
        "ol": result["random_output_len"],
        "completed": result["completed"],
        "duration": result["duration"],
        "metrics": {
            metric: {
                statistic: result[f"{statistic}_{metric}_ms"]
                for statistic in ("mean", "median", "p99", "std")
            }
            for metric in METRICS
        },
    }


def main() -> None:
    experiments = {}
    sources = {}
    for mode, config in MODES.items():
        sources[mode] = str(config["path"].relative_to(ROOT))
        for path in sorted(config["path"].glob("metrics_*.jsonl")):
            result = read_result(path)
            key = f"rr{result['rr']:g}_il{result['il']}_ol{result['ol']}"
            experiments.setdefault(key, {
                "key": key,
                "rr": result["rr"],
                "il": result["il"],
                "ol": result["ol"],
                "representative": (result["il"], result["ol"]) in REPRESENTATIVE_WORKLOADS,
                "results": {},
            })["results"][mode] = result

    incomplete = [key for key, item in experiments.items() if set(item["results"]) != set(MODES)]
    if incomplete:
        raise RuntimeError(f"Missing comparison data for: {', '.join(incomplete)}")

    payload = {
        "generatedFrom": sources,
        "modeLabels": {mode: config["label"] for mode, config in MODES.items()},
        "experiments": sorted(experiments.values(), key=lambda item: (item["rr"], item["il"], item["ol"])),
    }
    output = Path(__file__).with_name("data.js")
    output.write_text("window.PD_DATA = " + json.dumps(payload, ensure_ascii=False) + ";\n", encoding="utf-8")
    print(f"Generated {output} with {len(experiments)} matched experiments")


if __name__ == "__main__":
    main()