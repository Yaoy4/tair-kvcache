const state = { scope: "representative", statistic: "mean" };
const metricMeta = {
  ttft: { label: "TTFT", color: "#087f5b" },
  tpot: { label: "TPOT", color: "#087f5b" },
  e2e_latency: { label: "E2E", color: "#087f5b" },
};
const tooltip = document.querySelector("#tooltip");

function selectedExperiments() {
  return window.PD_DATA.experiments.filter(item => state.scope === "all" || item.representative);
}

function compactMs(value) {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(2)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(value >= 100_000 ? 0 : 1)}K`;
  return value.toFixed(value >= 100 ? 0 : 1);
}

function workloadLabel(item) {
  const token = value => value >= 1024 ? `${value / 1024}K` : value;
  return `R${item.rr} · ${token(item.il)}→${token(item.ol)}`;
}

function delta(item, metric) {
  const agg = item.results.aggregated.metrics[metric][state.statistic];
  const dis = item.results.disaggregated.metrics[metric][state.statistic];
  return (agg / dis - 1) * 100;
}

function deltaMarkup(value) {
  const tone = value <= 0 ? "good" : "bad";
  const sign = value > 0 ? "+" : "";
  return `<span class="${tone}">${sign}${value.toFixed(1)}%</span>`;
}

function renderSummary(items) {
  const averages = Object.keys(metricMeta).map(metric => ({
    metric,
    value: items.reduce((sum, item) => sum + delta(item, metric), 0) / items.length,
  }));
  const wins = items.reduce((count, item) => count + Object.keys(metricMeta).filter(metric => delta(item, metric) < 0).length, 0);
  document.querySelector("#summary").innerHTML = averages.map(({ metric, value }) => `
    <div class="summary-item"><span>${metricMeta[metric].label} 平均变化</span><strong>${deltaMarkup(value)}</strong><small>越低越好</small></div>
  `).join("") + `
    <div class="summary-item"><span>合并模式胜出</span><strong>${wins} / ${items.length * 3}</strong><small>样本 × 指标</small></div>
  `;
}

function renderChart(container, items, metric) {
  const width = Math.max(container.clientWidth - 16, 520);
  const height = container.clientHeight - 14;
  const margin = { top: 18, right: 16, bottom: 62, left: 58 };
  const chartWidth = width - margin.left - margin.right;
  const chartHeight = height - margin.top - margin.bottom;
  const values = items.flatMap(item => ["aggregated", "disaggregated"].map(mode => item.results[mode].metrics[metric][state.statistic]));
  const maxValue = Math.max(...values) * 1.08;
  const groupWidth = chartWidth / items.length;
  const barWidth = Math.min(24, Math.max(5, groupWidth * .28));
  const ticks = 4;
  let svg = `<svg viewBox="0 0 ${width} ${height}" role="img"><g transform="translate(${margin.left},${margin.top})">`;
  for (let tick = 0; tick <= ticks; tick += 1) {
    const y = chartHeight * tick / ticks;
    const value = maxValue * (1 - tick / ticks);
    svg += `<line class="grid-line" x1="0" y1="${y}" x2="${chartWidth}" y2="${y}"/><text class="axis-text" x="-9" y="${y + 3}" text-anchor="end">${compactMs(value)}</text>`;
  }
  items.forEach((item, index) => {
    const center = groupWidth * (index + .5);
    ["aggregated", "disaggregated"].forEach((mode, modeIndex) => {
      const value = item.results[mode].metrics[metric][state.statistic];
      const barHeight = value / maxValue * chartHeight;
      const x = center + (modeIndex - .5) * barWidth - barWidth / 2;
      const color = mode === "aggregated" ? "#087f5b" : "#e0523d";
      svg += `<rect class="bar" data-label="${workloadLabel(item)}" data-mode="${window.PD_DATA.modeLabels[mode]}" data-value="${value}" data-delta="${delta(item, metric)}" x="${x}" y="${chartHeight - barHeight}" width="${barWidth - 1}" height="${Math.max(barHeight, 1)}" fill="${color}"/>`;
    });
    const rotate = items.length > 9 ? -55 : -38;
    svg += `<text class="x-text" x="${center}" y="${chartHeight + 17}" text-anchor="end" transform="rotate(${rotate} ${center} ${chartHeight + 17})">${workloadLabel(item)}</text>`;
  });
  svg += `<text class="axis-text" transform="rotate(-90)" x="${-chartHeight / 2}" y="-44" text-anchor="middle">毫秒（ms）</text></g></svg>`;
  container.innerHTML = svg;
  container.querySelectorAll(".bar").forEach(bar => {
    bar.addEventListener("pointermove", event => {
      tooltip.innerHTML = `${bar.dataset.label}<br>${bar.dataset.mode}<br><b>${Number(bar.dataset.value).toFixed(2)} ms</b><br>合并变化 ${deltaMarkup(Number(bar.dataset.delta))}`;
      tooltip.style.left = `${event.clientX}px`;
      tooltip.style.top = `${event.clientY}px`;
      tooltip.classList.add("visible");
    });
    bar.addEventListener("pointerleave", () => tooltip.classList.remove("visible"));
  });
}

function renderTable(items) {
  document.querySelector("#delta-table").innerHTML = `
    <thead><tr><th>RR · IL→OL</th><th>TTFT</th><th>TPOT</th><th>E2E</th><th>合并耗时</th><th>分离耗时</th></tr></thead>
    <tbody>${items.map(item => `<tr>
      <td>${workloadLabel(item)}</td>
      ${Object.keys(metricMeta).map(metric => `<td class="delta">${deltaMarkup(delta(item, metric))}</td>`).join("")}
      <td>${item.results.aggregated.duration.toFixed(1)} s</td>
      <td>${item.results.disaggregated.duration.toFixed(1)} s</td>
    </tr>`).join("")}</tbody>`;
}

function renderValidation(items) {
  const allResults = items.flatMap(item => ["aggregated", "disaggregated"].map(mode => ({ item, mode, result: item.results[mode] })));
  const formulaErrors = allResults.map(({ item, result }) => {
    const predicted = result.metrics.ttft.mean + result.metrics.tpot.mean * (item.ol - 1);
    return Math.abs(predicted / result.metrics.e2e_latency.mean - 1) * 100;
  });
  const maxFormulaError = Math.max(...formulaErrors);
  const completed = allResults.every(({ result }) => result.completed === 200);
  const comparable = Object.values(window.PD_DATA.generatedFrom).length === 2 && window.PD_DATA.experiments.length === 18;
  document.querySelector("#validation").innerHTML = `
    <article class="check"><span class="tag">CHECK 01 · PASS</span><h3>请求完整性</h3><p>${completed ? "所有已选实验均完成 200 个请求，没有因失败请求造成的样本量偏差。" : "存在未完成请求，需要回查原始实验日志。"}</p></article>
    <article class="check"><span class="tag">CHECK 02 · ${maxFormulaError < 1 ? "PASS" : "REVIEW"}</span><h3>延迟公式闭合</h3><p>按 E2E ≈ TTFT + TPOT × (OL−1) 复算，当前样本最大相对误差为 ${maxFormulaError.toFixed(2)}%，三项指标内部一致。</p></article>
    <article class="check"><span class="tag">CHECK 03 · ${comparable ? "PASS" : "REVIEW"}</span><h3>对比条件</h3><p>两种模式各覆盖同一套 RR、IL、OL；PD 合并使用 TP=2，PD 分离使用 P1D1，共占用两块 GPU。</p></article>
  `;
}

function render() {
  const items = selectedExperiments();
  renderSummary(items);
  document.querySelectorAll(".chart-panel").forEach(panel => renderChart(panel.querySelector(".chart"), items, panel.dataset.metric));
  renderTable(items);
  renderValidation(items);
}

document.querySelectorAll(".segmented").forEach(control => {
  control.addEventListener("click", event => {
    if (!event.target.matches("button")) return;
    control.querySelectorAll("button").forEach(button => button.classList.toggle("active", button === event.target));
    state[control.id === "scope-control" ? "scope" : "statistic"] = event.target.dataset.value;
    render();
  });
});
document.querySelector("#source-note").textContent = Object.values(window.PD_DATA.generatedFrom).join(" ↔ ");
window.addEventListener("resize", render);
render();